<?php

return array(
	array(
		'name'   => 'JNews_Footer_Instagram',
		'type'   => 'carousel',
		'image'  => '',
		'widget' => false,
		'view'   => 'class/module/element/class-view.php',
		'option' => 'class/module/element/class-option.php',
	),
);
