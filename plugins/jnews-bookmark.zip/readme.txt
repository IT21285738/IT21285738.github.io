Change Log :

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0
- [IMPROVEMENT] Bookmark button on JNews Post Meta View element

== 9.0.2 ==
- [BUG] Fix Active License in Bookmark Option issue
- [BUG] Fix Captcha not Loaded issue

== 9.0.1 ==
- [BUG] Fix PHP 5.6 issue

== 9.0.0 ==
- First Release